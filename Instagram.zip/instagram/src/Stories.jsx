
import { useState,useEffect } from 'react';

function Stories() {
  const [stories ,setStories] =useState([]);

  useEffect (()=>{
    fetch('http://localhost:3500/story')
    .then(data => data.json())
    .then(data =>setStories(data))
    .catch(err => console.log(data))

  },[]);
  return (
    <div>
      <div className='story d-flex ' >
        {stories.length > 0 ? (
          stories.map((story) =>(
            <div key={story.id} className='mx-1' onclick={}>
              <div className='gradient-border'>
            <img src={story.profilePic} alt="dp" className='story-dp rounded-circle' />
            </div>
            <p className='text-truncate' style={{width:"50px"}}>{story.username}</p>
          </div>
          ))
        ):(
          <p>Loading </p>
        )}

      </div>
    </div>
  )
}

export default Stories
