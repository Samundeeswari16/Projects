import React from 'react'
import { useParams ,Link } from 'react-router-dom'
import react,{useEffect,useState ,useNavigate} from 'react'

function ViewStory() {

const {id ,tot} =useParams();
const navigate = useNavigate();

const [story,setStory] = useState(null);

useEffect(()=>{
 fetch(`http://localhost:3500/story/${id}`)
 .then(data => data.json())
 .then(data => setStory(data))
 .catch(err => console.log(err))
},[id])
if(id > tot || id <= 0){
  navigate('/');
}
  return (
    
    <div>
      
      {story ?  <div className='d-flex justify-content-center'>
        <Link to ={`http://localhost:3500/story/${Number(id)-1}/${tot}`}> <i class="bi bi-arrow-left-square"></i></Link> 
       <img  src={story.image} className='vh-100' alt="story" />
          <Link to={`http://localhost:3500/story/${Number(id)+1}/${tot}`}> <i class="bi bi-arrow-right-square"></i></Link>
        </div> : 
        <div> loading </div>}
    </div>
  )
}

export default ViewStory
